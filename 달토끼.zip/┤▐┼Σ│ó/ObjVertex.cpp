#include "pch.h"
#include "ObjVertex.h"



CObjVertex::CObjVertex()
{
	x = 0;
	y = 0;
	z = 0;
}


CObjVertex::~CObjVertex()
{
}
