#include "pch.h"
#include "Colleague.h"


CColleague::CColleague()
{

}


CColleague::~CColleague()
{

}
