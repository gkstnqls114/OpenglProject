#include "pch.h"
#include "ClearObject.h"


CClearObject::CClearObject()
{
}


CClearObject::~CClearObject()
{
}

void CClearObject::Render()
{
}

void CClearObject::Update()
{
}
