#pragma once
class CTextureData
{

public:
	CTextureData();
	~CTextureData();
};

