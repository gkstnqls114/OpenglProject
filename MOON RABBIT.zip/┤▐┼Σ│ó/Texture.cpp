#include "pch.h"
#include "Texture.h"


CTextureData::CTextureData()
{
}


CTextureData::~CTextureData()
{
}
